package com.example.uiservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UiServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
