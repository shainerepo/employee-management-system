package com.example.uiservice.data;

import lombok.Data;

@Data
public class Order {

    private int orderId;
    private double totalPrice;

}
