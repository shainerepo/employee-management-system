I was more focused on the backend, so frontend is quite simple
